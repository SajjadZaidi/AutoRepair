@javax.xml.bind.annotation.XmlSchema(namespace = "http://com.wordnik/sample/model", elementFormDefault = javax.xml.bind.annotation.XmlNsForm.QUALIFIED)
package com.wordnik.sample.model;
