var HelloWorld = function() {
  this.greeting = function() {
    return "Hello, World";
  }
}