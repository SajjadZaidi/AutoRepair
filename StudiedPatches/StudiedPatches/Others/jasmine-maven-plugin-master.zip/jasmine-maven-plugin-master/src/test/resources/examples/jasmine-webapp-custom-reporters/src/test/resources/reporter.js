(function() {
  var jasmineMavenPlugin = window.jasmineMavenPlugin = window.jasmineMavenPlugin || {};

  jasmineMavenPlugin.printReport = function(r, config) {
    return window.exampleTest;
  };
})();
