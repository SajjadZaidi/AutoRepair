xdescribe('Slice-o-matic',function(){

  it('occupies the SliceOMatic namespace',function(){});

  describe('#slice',function() {

    it('slices',function() {});

    it('does not dice',function(){});

    xit('prevents cuts to your thumb',function(){});
  });

  describe('#dice',function() {

    describe('when the onion is peeled',function() {
      it('dices evenly-sized cubes',function() {});
    });

    describe('when the knob is turned to "Fine"',function() {
      it('dices quite finely',function() {});
      it("does not cut off fingers", function() {});
    });

    describe('when the knob is turned to "Coarse"',function() {
      it('dices rather roughly',function() {});
    });

    describe("when a hand is inserted into the Slice-o-matic", function() {
      it("is a fantastic idea", function() {
          expect("Are you kidding? That's a terrible idea!").toContain('Great idea');
      });
    });
  });
});
