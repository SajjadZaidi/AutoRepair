var fileSystemReporter;
(function() {
  fileSystemReporter = {
    report: function(reporter, debug) {
      return window.exampleTest;
    }
  };
})();
