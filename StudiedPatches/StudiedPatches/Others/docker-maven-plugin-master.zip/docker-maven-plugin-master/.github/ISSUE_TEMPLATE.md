## Description

[Add feature/bug description here]

## How to reproduce

[Add steps on how to reproduce this issue]

## What do you expect

[Describe what do you expect to happen]

## What happened instead

[Describe the actual results]

## Software:

- docker version: [Add docker version here, client and server]
- docker-maven-plugin version: [Add docker-maven-plugin version here]
- maven version: [Add maven version here]

## Full backtrace

```text
[Paste full backtrace here]
```
