(function(window) {
  window.util = {
    append : function(string,suffix) {
      return string+suffix;
    }
  };
})(this);