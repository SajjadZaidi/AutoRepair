describe("window.A", function() {
  it("is defined", function() {
    expect(window.A).toBeDefined();
  });
});