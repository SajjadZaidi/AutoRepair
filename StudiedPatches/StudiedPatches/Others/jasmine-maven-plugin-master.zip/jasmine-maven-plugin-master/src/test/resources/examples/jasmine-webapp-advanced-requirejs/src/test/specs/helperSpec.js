define(['lib/jquery', 'lib/jquery.simplePlugin', 'specs/lib/jasmine-jquery'], function(jQuery) {
  return jQuery;
});