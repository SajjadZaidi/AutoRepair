#ifndef LIBTEST1_H
#define LIBTEST1_H

void test1();

#endif /* LIBTEST1_H */
