package com.wordnik.sample.model;

/**
 * @author chekong on 15/5/12.
 */
public enum PetStatus {
    AVAILABLE,
    PENDING,
    SOLD
}