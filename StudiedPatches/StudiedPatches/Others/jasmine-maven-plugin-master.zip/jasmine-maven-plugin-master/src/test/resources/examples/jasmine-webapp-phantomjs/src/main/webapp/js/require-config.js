(function() {
    require.config({
        paths: {
            jquery: "http://cdnjs.cloudflare.com/ajax/libs/jquery/1.9.1/jquery",
            kinetic: "http://cdnjs.cloudflare.com/ajax/libs/kineticjs/4.3.1/kinetic.min"
        }
    });
}());