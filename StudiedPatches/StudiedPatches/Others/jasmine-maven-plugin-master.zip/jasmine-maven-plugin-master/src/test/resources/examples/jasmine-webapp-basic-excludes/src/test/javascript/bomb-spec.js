describe("bomba", function() {
  it("bombs", function() {
    throw "spec bomb";
  });
});