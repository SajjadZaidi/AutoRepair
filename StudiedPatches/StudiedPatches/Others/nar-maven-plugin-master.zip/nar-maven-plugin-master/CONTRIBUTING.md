For contribution guidelines, please read the
[How to contribute](https://github.com/maven-nar/nar-maven-plugin/wiki/How-to-contribute)
page of the NAR wiki!
