var foo = true;
