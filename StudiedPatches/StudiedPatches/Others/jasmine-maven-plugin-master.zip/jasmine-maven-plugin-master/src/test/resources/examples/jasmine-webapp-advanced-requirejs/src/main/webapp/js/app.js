define(['lib/jquery'], function($) {
  return {
    addDatePickerToElement: function(element) {
      element.datepicker();
    }
  }
});