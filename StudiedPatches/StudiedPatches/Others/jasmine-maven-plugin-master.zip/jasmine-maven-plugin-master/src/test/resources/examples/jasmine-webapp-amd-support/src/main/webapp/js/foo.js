define(function() {
  return {
    foo: function(bar) {
      return "Foo" + bar;
    }
  }
})