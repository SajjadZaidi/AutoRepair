#ifndef LIBTEST2_H
#define LIBTEST2_H

void test2();

#endif /* LIBTEST2_H */
